package com.hcl8;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class Config {
	@Bean(name="course1")
public Course course() {
	Course course1 = new Course();
	course1.setName("Java");
	course1.setMentor("sathish");
	course1.setFee(1000.0);
	return course1;
	}
	
@Bean(name="course2")
public Course course1() {
	Course course2 =new Course();
	course2.setName("Selenium");
	course2.setMentor("Kanimozhi");
	course2.setFee(2000.0);
	return course2;
	
}
@Bean(name="course3")
public Course course2() {
	Course course3 = new Course();
	course3.setName("Python");
	course3.setMentor("Arun");
	course3.setFee(500.0);
	return course3;
	
}

}
