package com.hcl5;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration

public class Config {
	@Bean(name="employee")
	public Employee emp() {
		Employee employee = new Employee();
		employee.setEmployeeName("suba");
		employee.setEmployeeMobileNumber(765657888);
		employee.setEmployeeSalary((long) 30000);
		employee.setEmployeeEmail("suba@123");
		return employee;
		
	}
	@Bean(name="address")
	public Address add() {
		Address address = new Address();
		address.setLine1("Anna Nagar");
		address.setLine2("porur");
		address.setCity("chennai");
		address.setPincode("609606");
		return address;
	}

}
