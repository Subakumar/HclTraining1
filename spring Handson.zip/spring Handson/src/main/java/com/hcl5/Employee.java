package com.hcl5;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class Employee {
	private String employeeName;
	private Integer employeeMobileNumber;
	private Long employeeSalary;
	private String employeeEmail;
	private Address address;
	
	public Employee() {
		
	}

	public Employee(String employeeName, Integer employeeMobileNumber, Long employeeSalary, String employeeEmail,
			Address address) {
		super();
		this.employeeName = employeeName;
		this.employeeMobileNumber = employeeMobileNumber;
		this.employeeSalary = employeeSalary;
		this.employeeEmail = employeeEmail;
		this.address = address;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public Integer getEmployeeMobileNumber() {
		return employeeMobileNumber;
	}

	public void setEmployeeMobileNumber(Integer employeeMobileNumber) {
		this.employeeMobileNumber = employeeMobileNumber;
	}

	public Long getEmployeeSalary() {
		return employeeSalary;
	}

	public void setEmployeeSalary(Long employeeSalary) {
		this.employeeSalary = employeeSalary;
	}

	public String getEmployeeEmail() {
		return employeeEmail;
	}

	public void setEmployeeEmail(String employeeEmail) {
		this.employeeEmail = employeeEmail;
	}

	public Address getAddress() {
		return address;
	}
@Autowired
	public void setAddress(Address address) {
		this.address = address;
	}
public void display() {
	System.out.println("Name:"+employeeName);
	System.out.println("MobileNumber:"+employeeMobileNumber);
	System.out.println("Salary:"+employeeSalary);
	System.out.println("Email:"+employeeEmail);
	address.display();
}
	

}
