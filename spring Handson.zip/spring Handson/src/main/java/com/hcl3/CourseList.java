package com.hcl3;

import java.util.ArrayList;



public class CourseList {
	ArrayList<Course> courselist = new ArrayList<Course>();

	public void insert(Course course) {
		courselist.add(course);
	}
	public double revenue() {
		
		double Revenue = 0.0 ;
		for(Course course:courselist) {
			Revenue = Revenue+course.getFee()*200*0.2;
		}
		return Revenue;
	}
}
