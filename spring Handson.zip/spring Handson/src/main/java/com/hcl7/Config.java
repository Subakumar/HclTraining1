package com.hcl7;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class Config {
	
	@Bean (name="user")
public User user() {
User user1 = new User();
user1.setName("Jegan");
user1.setAge(24);
user1.setCity("chennai");

return user1;

	}
	@Bean (name="order1")
	public Order order1() {
		Order order1 = new Order();
		order1.setItemName("Item1");
		order1.setPrice(230.07);
		return order1;
	}
	@Bean(name ="order2")
	public Order order2() {
		Order order2 = new Order();
		order2.setItemName("Item2");
		order2.setPrice(230.07);
		return order2;
		}
	}
	

