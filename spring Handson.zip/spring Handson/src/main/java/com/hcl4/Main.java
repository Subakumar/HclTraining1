package com.hcl4;

import javax.naming.Context;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Main {

	public static void main(String[] args) {
		ApplicationContext context = new AnnotationConfigApplicationContext(Anno.class);
		Owner owner = context.getBean(Owner.class);
		owner.setName("suba");
		owner.setMobileNumber("7565645464");
		owner.setPassword("sub@123");
		owner.display();
		((AnnotationConfigApplicationContext)context).close();
		
	}
   
}
