package com.hcl2;

import java.util.ArrayList;

public class CourseList {
	ArrayList<Course> courselist = new ArrayList<Course>();

	public void insert(Course course) {
		courselist.add(course);
	}

	public void discount() {
		double maximumfee = 0;
		double minimumFee = 2000;
		String Name=null;
		String Name1=null;
		double Total=0;
		double Total1=0;
		double amount1=0;
		double amount=0;
		
		
		for (Course courses : courselist) {
			if (courses.getFee() >= maximumfee) {
				amount = courses.getFee();
				Name = courses.getName();
				 Total = (0.1 * amount);
			}
		}
        for (Course course : courselist) {
				if (course.getFee()<=minimumFee) {
					amount1 = course.getFee();
					Name1 = course.getName();
					 Total1 = (0.05 * amount1);
				}
		}
        System.out.println("Discount"+"\t"+Total+"\t"+"for"+"\t"+Name);
        System.out.println("Discount"+"\t"+Total1+"\t"+"for"+"\t"+Name1);
	
		
	}

	
	
	}
