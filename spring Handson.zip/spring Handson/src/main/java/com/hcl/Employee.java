package com.hcl;

import java.util.ArrayList;
import java.util.List;

public class Employee {
	private String employeeName;
	private List<String> employeeMobileNumber;
	private Long salary;
	private String employeeEmail;
	private Address address;
	
	public Employee() {
		
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public List<String> getEmployeeMobileNumber() {
		return employeeMobileNumber;
	}

	public void setEmployeeMobileNumber(List<String> employeeMobileNumber) {
		this.employeeMobileNumber = employeeMobileNumber;
	}

	public Long getSalary() {
		return salary;
	}

	public void setSalary(Long salary) {
		this.salary = salary;
	}

	public String getEmployeeEmail() {
		return employeeEmail;
	}

	public void setEmployeeEmail(String employeeEmail) {
		this.employeeEmail = employeeEmail;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public Employee(String employeeName, List<String> employeeMobileNumber, Long salary, String employeeEmail,
			Address address) {
		super();
		this.employeeName = employeeName;
		this.employeeMobileNumber = employeeMobileNumber;
		this.salary = salary;
		this.employeeEmail = employeeEmail;
		this.address = address;
	}
	
	public void display() {
		System.out.println("Name:"+employeeName);
		
	    System.out.println("The contact numbers are:");
	    for(String number:employeeMobileNumber) {
	    	System.out.println(number);
	    }
		
		System.out.println("Salary:"+salary);
		System.out.println("Email:"+employeeEmail);
		address.display();
	
		
	}

}
