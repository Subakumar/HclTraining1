package com.hcl1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {

	public static void main(String[] args)throws NumberFormatException,IOException {
	    CourseList courselist = new CourseList();
	    ArrayList<String>budgetlist = new ArrayList<>();
		ApplicationContext context=new ClassPathXmlApplicationContext("applicationContext1.xml");
		Course course1 = context.getBean("course1",Course.class);
		Course course2 = context.getBean("course2",Course.class);
		Course course3 = context.getBean("course3",Course.class);
		
		courselist.insert(course1);
		courselist.insert(course2);
		courselist.insert(course3);
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter your Budget:");
		Double budget = Double.parseDouble(br.readLine());
		budgetlist = courselist.noOfCourse(budget);
		if(budgetlist.isEmpty()) {
			System.out.println("No course available");
		}
		else {
			for(String s:budgetlist) {
				System.out.println(s);
			}
		}
		
		
		((ClassPathXmlApplicationContext)context).close();

	}

}
