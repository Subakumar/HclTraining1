package com.hcl1;

import java.util.ArrayList;

public class CourseList {
	ArrayList<Course> list = new ArrayList<Course>();

	public void insert(Course course) {
		list.add(course);
	}

	public ArrayList<String> noOfCourse(Double budget) {
		ArrayList<String> list1 = new ArrayList<String>();
		for (Course courses : list) {
			if (budget>= courses.getFee()) {
				int c = (int) (budget / courses.getFee());
				list1.add(courses.getName() + "_" + c);
			}

		}
		return list1;

	}

}
