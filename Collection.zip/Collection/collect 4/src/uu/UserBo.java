package uu;
import java.util.ArrayList;

public class UserBo extends ArrayList{
static UserBo b = new UserBo();
void removeUser(int n1, int n2) {
	removeRange(n1,n2);
}
	static UserBo getList() {
		b.add(new User("suba laksh","7598587978","suba","suba@abc.in"));
	    b.add(new User("Janani","9750004787","janu","janu@abc.in"));
	    b.add(new User("kamali","9965786687","kamzz","kamzz@abc.in"));
	    return b;
	}
	}


