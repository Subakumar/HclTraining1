package uu;
import java.util.*;
public class Main {

	public static void main(String[] args) {
		UserBo u = new UserBo();
		User u1 = new User();
		User u2 = new User();
		u.addAll(u.getList());
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		for(int i=1;i<=n;i++) {
			System.out.println("Enter the user"+i+"detail in CSV format");
			String s = sc.nextLine();
			String[] str = s.split(",");
			u.add(new User(str[0],str[1],str[2],str[3]));
		}
		Iterator itr = u.iterator();
		System.out.format("%-20s%-20s%-20s%-20s","name","contactNumber","userName","email");
		System.out.println();
		while(itr.hasNext()) {
			u1 = (User) itr.next();
			u1.display();
			
		}
		System.out.println("Enter the range to be removed from arraylist:");
		int n1 = sc.nextInt();
		int n2 = sc.nextInt();
		u.removeUser(n1, n2);
	
	
	Iterator itr1 = u.iterator();
	System.out.format("%-20s%-20s%-20s%-20s","name","contactNumber","userName","email");
	
	while(itr.hasNext()) {
		u2 = (User) itr1.next();
		u2.display();
	
	}
}
}
