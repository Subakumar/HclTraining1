package collect0;
import java.util.*;

public class Collect {

	public static void main(String[] args) {
		ArrayList al =new ArrayList();
		Scanner sc = new Scanner(System.in);
		int i=1;
		System.out.println("enter the username:"+i);
		String name = sc.nextLine();
		al.add(name);
		do {
			System.out.println("Do you want to continue?");
			String s2 = sc.nextLine();
			if(s2.equals("yes")) {
				i++;
				System.out.println("enter the username:"+i);
				String name2 = sc.nextLine();
				al.add(name2);
			}
			else {
				break;
			}
			
		}while(true);
		
		Iterator itr = al.iterator();
		System.out.println("The entered names are:");
		while(itr.hasNext()) {
			System.out.println(itr.next());
		}
		

	}

}
