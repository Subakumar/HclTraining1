package bb;
import java.util.ArrayList;
import java.util.*;
public class Main {

	public static void main(String[] args) {
		ArrayList a = new ArrayList();
		Scanner sc = new Scanner(System.in);
		int i=1;
		System.out.println("enter the details:"+i);
		do {
			System.out.println("name");
			String name = sc.nextLine();
		
			System.out.println("deposit");
			Double deposit = sc.nextDouble();
	
			System.out.println("costPerDay");
			Double cost= sc.nextDouble();
			sc.nextLine();
			
			Collect c = new Collect(name,deposit,cost);
			a.add(c);
			System.out.println("Do you want to continue:");
			String s1 = sc.nextLine();
			sc.nextLine();
			if(s1.equals("yes")) {
				i++;
				System.out.println("enter the details:"+i);
			}
			else 
				break;
			
		}while(true);
		
			Iterator<Collect> itr = a.iterator();
			System.out.println("The entered names are:");
			while(itr.hasNext()) {
				Collect col = itr.next();
				System.out.println(col);
			}
			
			
		
		}
		
	}


