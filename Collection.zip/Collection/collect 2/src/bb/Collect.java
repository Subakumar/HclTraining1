package bb;

public class Collect {
	String name;
	Double deposit;
	Double costPerDay;

	public Collect() {

	}

	public Collect(String name, Double deposit, Double costPerDay) {
		super();
		this.name = name;
		this.deposit = deposit;
		this.costPerDay = costPerDay;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Double getDeposit() {
		return deposit;
	}

	public void setDeposit(Double deposit) {
		this.deposit = deposit;
	}

	public Double getCostPerDay() {
		return costPerDay;
	}

	public void setCostPerDay(Double costPerDay) {
		this.costPerDay = costPerDay;
	}

	@Override
	public String toString() {
		System.out.format("%-20s%-20s%-20s%-20s","Name","Deposit","costPerDay" +"\t"+"\n"+name,deposit,costPerDay);
		return "";
	}



}
