package uu;

import java.util.HashSet;
import java.util.Scanner;

public class UserEntry {

	public static void main(String[] args) {
HashSet s = new HashSet();
		
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the username:");
		String name = sc.nextLine();
		s.add(name);
		do {
			System.out.println("Do you want to continue?");
			String s2 = sc.nextLine();
			if(s2.equals("yes")) {
				
				System.out.println("enter the username:");
				String name2 = sc.nextLine();
				s.add(name2);
			
		}
			else {
				break;
			}
		}while(true);
		System.out.println("The Unique number of users"+s.size());
		
	}

	}


