package hh;
import java.util.*;
public class Hall {

	public static void main(String[] args) {

ArrayList a1 = new ArrayList();
Scanner sc= new Scanner(System.in);
System.out.println("enter the number of halls:");
int n = sc.nextInt();
for(int i =1;i<=n;i++) {
	System.out.println("enter the hall name :"+i);
	sc.nextLine();
	String name = sc.nextLine();
	a1.add(name);

}
System.out.println("enter the hall to be searched:");
String hall = sc.nextLine();
if(a1.contains(hall)) {
	System.out.println("The position of the"+hall+ "is"+ a1.indexOf(hall));
}
else {
	System.out.println("The hall is not found");
}

	}

}
