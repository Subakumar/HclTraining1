package dd;
import java.util.*;

public class Main {

	public static void main(String[] args) {
		Hdfc h = new Hdfc();
		AxisBank a = new  AxisBank();
		Icici i = new Icici();
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the number:");
		int n = sc.nextInt();
		switch(n) {
		
		case 1:
		System.out.println(" Enter the amount you want to invest");
		int amount = sc.nextInt();
		
		a.setAmount(amount);
		System.out.println("Enter the tenure of the SIP");
		int tenure = sc.nextInt();
		a.setTen(tenure);
		a.calcAxis(amount,tenure);
		sc.nextLine();
		break;
		
		case 2:
		System.out.println(" Enter the amount you want to invest");
		int amount1 = sc.nextInt();
		h.setAmount(amount1);
		System.out.println("Enter the tenure of the SIP");
		int tenure1 = sc.nextInt();
		h.setTen(tenure1);
		h.calcHdfc(amount1,tenure1);
		sc.nextLine();
		break;
		
		case 3:
		System.out.println(" Enter the amount you want to invest");
		int amount2 = sc.nextInt();
		i.setAmount(amount2);
		System.out.println("Enter the tenure of the SIP");
		int tenure2 = sc.nextInt();
		i.setTen(tenure2);
		i.calcIcici(amount2,tenure2);
		break;
		}
		
		
		
		
		}
	}
	


