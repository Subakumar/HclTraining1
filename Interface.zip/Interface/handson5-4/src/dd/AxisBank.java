package dd;

public class AxisBank implements MutualFund{
	int amount;
	int ten;
	public AxisBank() {
		
	}
	
public AxisBank(int amount, int ten) {
		super();
		this.amount = amount;
		this.ten = ten;
	}

public int getAmount() {
	return amount;
}

public void setAmount(int amount) {
	this.amount = amount;
}

public int getTen() {
	return ten;
}

public void setTen(int ten) {
	this.ten = ten;
}


public void duration() {
	System.out.println("enter the tenure of the SIP:");
	
}
public void amount() {
	System.out.println("enter the amount you want to invest:");
	
}
	void calcAxis(Integer amount,Integer ten){ 
		
		double total;
	total = (amount*ten*56)/100;
	System.out.println("You will have returns as" +total);
	}
}
