package dd;

public interface MutualFund {

	void duration();
	void amount();
	
}
