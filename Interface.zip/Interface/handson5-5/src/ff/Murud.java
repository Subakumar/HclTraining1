package ff;

public class Murud implements Fort {

	public void distance() {
		System.out.println("The distance is 93km");
	}
}
