package ff;

public class Rajmachi implements Fort {
	
	
public void distance() {
	System.out.println("The distance is 55km");
}
}
