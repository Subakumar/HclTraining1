package ff;
import java.util.*;
public class Main {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.println("What you want to visit:");
		System.out.println("Rajmachi");
		System.out.println("Shivagad");
		System.out.println("Murud");
		Rajmachi r = new Rajmachi();
		Shivgadh s = new Shivgadh();
		Murud m = new Murud();
		
		System.out.println("enter the place:");
		String place = sc.nextLine();
		if(place.equals("Rajmachi")){
			
		System.out.println("after choosing rajmachi");
			r.distance();
		}
		else if (place.equals("Shivagad")) {
			System.out.println("after choosing shivagad");
			s.distance();
		}
		else if(place.equals("murud")) {
			System.out.println("after choosing murud");
			m.distance();
		}
		else {
			System.out.println("invalid");
		}
		
		
	}

}
