package bb;

public class Rectangle implements Polygon {
double length;
double breadth;
public Rectangle() {
	
}
	public void calcPeri() {
		double peri1 = 2*(length+breadth);
	
		System.out.println("Perimeter of a rectangle:"+peri1);;
	}
public void calcArea() {
		double area1 = length+breadth;
		System.out.println("Area of a rectangle:"+area1);
	}
	public Rectangle(double length, double breadth) {
		super();
		this.length = length;
		this.breadth = breadth;
	}
	public double getLength() {
		return length;
	}
	public void setLength(double length) {
		this.length = length;
	}
	public double getBreadth() {
		return breadth;
	}
	public void setBreadth(double breadth) {
		this.breadth = breadth;
	}
	
}
