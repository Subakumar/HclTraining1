package bb;
import java.util.*;
public class Main {

	public static void main(String[] args) {
		Rectangle r = new Rectangle();
		Square s = new Square();
	Scanner sc = new Scanner(System.in);
	System.out.println("entr the length:");
	double leng = sc.nextDouble();
	System.out.println("enter the breadth");
	double bre = sc.nextDouble();
	System.out.println("enter the side:");
	double side = sc.nextDouble();
	
	r.setBreadth(bre);
	r.setLength(leng);
	s.setSide(side);
	r.calcArea();
	r.calcPeri();
	s.calcArea();
	s.calcPeri();
	
	

	}

}
