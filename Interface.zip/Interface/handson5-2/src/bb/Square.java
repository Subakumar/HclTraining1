package bb;

public class Square implements Polygon {
double side;

public Square() {
	
}



public Square(double side) {
	super();
	this.side = side;
}



public double getSide() {
	return side;
}



public void setSide(double side) {
	this.side = side;
}



public void calcPeri() {
	double peri2 = 4*side;
	System.out.println("Perimeter of a square:"+peri2);
		
	}
	public void calcArea() {
		double area2= side*side;
		System.out.println("area of a square:"+area2);;
		
	}
}
