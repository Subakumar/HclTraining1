package com.jdbc3;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

public class Update {

	public static void main(String[] args) {
		Connection con =null;
		
		PreparedStatement stmt=null;
		ResultSet rs = null;
		
	
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/hcl","root","root");
			if(con!=null) { 
				 stmt = con.prepareStatement("UPDATE  student  set FirstName=?WHERE Id =?");
				 
				stmt.setString(1, "Sorna");
				stmt.setInt(2, 2);
			
				int i =stmt.executeUpdate();
				if(i>0) {
					System.out.println(i);
				}
				else {
					System.out.println("not updated");
				}
				rs = stmt.executeQuery("select*from student");
				while(rs.next()) {
					System.out.println(rs.getInt(1)+""+rs.getString(2)+""+rs.getString(3)+rs.getString(4));
				}
				stmt.close();
				con.close();
				
	}

}catch(Exception e) {
	System.out.println(e);
}
	}
}
		
