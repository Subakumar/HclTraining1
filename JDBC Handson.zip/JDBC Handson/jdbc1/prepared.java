package com.jdbc1;
import java.sql.*;

public class prepared {

	public static void main(String[] args)throws ClassNotFoundException, SQLException {
		Connection con =null;
		Statement st = null;
		PreparedStatement stmt=null;
	
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/hcl","root","root");
			if(con!=null) { 
				 stmt = con.prepareStatement("insert into student values(?,?,?,?)");
				stmt.setInt(1, 5);
				stmt.setString(2,"gk");
				stmt.setString(3, "suba");
				stmt.setString(4, "kkl");
				
				int i = stmt.executeUpdate();
				if(i>0) {
					System.out.println("successfully added");
				}
				else {
					System.out.println("not added");
				}
				
			}
		}
		catch(Exception e) {
			System.out.println(e);
		}
		
	}

}
