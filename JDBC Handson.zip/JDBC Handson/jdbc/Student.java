package com.jdbc;
import java.sql.*;
public class Student {

	public static void main(String[] args)throws ClassNotFoundException ,SQLException {
		Connection con =null;
		Statement st =null;
		ResultSet rs =null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/hcl","root","root");
			if(con!=null) {
				st= con.createStatement();
				rs = st.executeQuery("select*from student");
				while(rs.next()) {
					System.out.println(rs.getInt(1)+""+rs.getString(2)+""+rs.getString(3)+rs.getString(4));
				}
				st.close();
				con.close();
		}
		}
		catch(Exception e) {
			System.out.println(e);
			
		}
		
		}

	}


