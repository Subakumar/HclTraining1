package com.jdbc2;
import java.sql.*;
import java.util.Scanner;
public class State {

	public static void main(String[] args) {
		String url ="jdbc:mysql://localhost:3306/hcl";
		String uname ="root";
		String pwd = "root";
		Connection con =null;
		PreparedStatement stmt =null;
		ResultSet rs =null;
		
		
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the id:");
		int id = sc.nextInt();
		
		System.out.println("enter the Fname:");
		String FName = sc.nextLine();
		sc.nextLine();
		System.out.println("enter the LName:");
		String LName = sc.nextLine();
		sc.nextLine();
		System.out.println("enter the city:");
		String city = sc.nextLine();
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection(url,uname,pwd);
			if(con!=null) {
				 stmt =con.prepareStatement("insert into student values(?,?,?,?)");
				stmt.setInt(1, id);
				stmt.setString(2, FName);
				stmt.setString(3,LName);
				stmt.setString(4, city);
				int i = stmt.executeUpdate();
				if(i>0) {
					System.out.println("successfully added");
				}
				else
					System.out.println("not added");
				
				rs = stmt.executeQuery("select * from student");
				while(rs.next()) {
					System.out.println(rs.getInt(1)+""+rs.getString(2)+""+rs.getString(3)+""+rs.getString(4));
				}
				
				con.close();
			}
		}
				catch(Exception e) {
					System.out.println(e);
				}
			}
		
		

	}


