package sm;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.*;
public class Main {

	public static void main(String[] args)throws IOException,NumberFormatException {
		HashMap<String,HashMap<String,List<Address>>> h1 = new HashMap();
		HashMap<String,List<Address>> h = new HashMap();
		List<Address> l = new ArrayList();
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter the number of Address:");
		int n = Integer.parseInt(br.readLine());
		for(int i=1;i<=n;i++) {
			System.out.println("enter the address"+ i+ "detail");
			String s = br.readLine();
			String str[]= s.split(",");
			String line1 = str[0];
			String line2 = str[1];
			String city = str[2];
			String state = str[3];
			int pincode = Integer.parseInt(str[4]);
			l.add(new Address(line1,line2,city,state,pincode));
			
			h.put(str[2],l);
			h1.put(str[3],h);
		}
		System.out.println("enter the state to be searched");
		String state = br.readLine();
		if(h1.containsKey(state)) {
			System.out.println("enter the city to be searched");
			String city =br.readLine();
			if(h.containsKey(city)) {
				System.out.format("%-15s %-15s %-15s %-15s %s\n","Line1","Line","city","state","pincode");
				Iterator<Address> itr = h.get(city).iterator();
				while(itr.hasNext()) {
					Address a = itr.next();
					if(a.getCity().equals(city)) {
						System.out.println(a);
					}
					}
				
				}else {
					System.out.println("searched city is not found");
				}
			
			}else {
				System.out.println("searched state is not found");
		}

	}

}
