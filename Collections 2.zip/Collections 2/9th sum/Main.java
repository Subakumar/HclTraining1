package bb;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.*;

import ss.Lists1;

public class Main {

	public static void main(String[] args)throws IOException,NumberFormatException {
		List<User> l = new ArrayList();
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter the number of user details:");
		int n = Integer.parseInt(br.readLine());
		for(int i=1;i<=n;i++) {
			System.out.println("enter the user"+i+"detail");
			String str = br.readLine();
			String s1[]= str.split(",");
			String name = s1[0];
	        String email = s1[1];
	        String username = s1[2];
	        String password =s1[3];
	        l.add(new User(name,email,username,password));

	}
System.out.println("Search by"+"1.name"+"2.email");
System.out.println("enter the choice:");
int ch = Integer.parseInt(br.readLine());
switch(ch) {
case 1:
	System.out.println("enter the name:");
	String name = br.readLine();
	Collections.sort(l);
	
	int a=Collections.binarySearch(l,new User(name,null,null,null),null);
	if(a>=0) {
		System.out.format("%-15s %-15s %-15s %s\n", "name","email","username","password");
		User u1 = l.get(a);
		System.out.println(u1);
		
	}
	else {
		System.out.println("name is not found");
		
	}
	break;
	
case 2:
	System.out.println("enter the email:");
	String email = br.readLine();
	Collections.sort(l,new EmailComparator());
	int b =Collections.binarySearch(l,new User(null,email,null,null),new EmailComparator());
	if(b>=0) {
		System.out.format("%-15s %-15s %-15s %s\n", "name","email","username","password");
		User u2 = l.get(b);
		System.out.println(u2);
		
	}
	else {
		
		System.out.println("email is not found");
	}
}

}
}