package ii;

public class Address implements Comparable {
private String username;
private String AddressLine1;
private String AddressLine2;
private Integer pinCode;
	
public Address() {
	
}

public Address(String username, String addressLine1, String addressLine2, Integer pinCode) {
	super();
	this.username = username;
	AddressLine1 = addressLine1;
	AddressLine2 = addressLine2;
	this.pinCode = pinCode;
}

public String getUsername() {
	return username;
}

public void setUsername(String username) {
	this.username = username;
}

public String getAddressLine1() {
	return AddressLine1;
}

public void setAddressLine1(String addressLine1) {
	AddressLine1 = addressLine1;
}

public String getAddressLine2() {
	return AddressLine2;
}

public void setAddressLine2(String addressLine2) {
	AddressLine2 = addressLine2;
}

public Integer getPinCode() {
	return pinCode;
}

public void setPinCode(Integer pinCode) {
	this.pinCode = pinCode;
}

@Override
public int compareTo(Object o) {
	Address a = (Address)o;
	if(a.getPinCode()<pinCode)
		return 1;
	else if(a.getPinCode()>pinCode)
		return -1;
	else if(a.getPinCode()==pinCode)
		return a.getAddressLine1().compareTo(AddressLine1);	
	return 0;
}

@Override
public String toString() {
	return username+"\t"+ AddressLine1+"\t"+AddressLine2+"\t"+pinCode ;
}




}








