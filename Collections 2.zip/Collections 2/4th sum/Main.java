package ii;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import ss.Lists1;

public class Main {

	public static void main(String[] args)throws IOException,NumberFormatException {
		List<Address> l = new ArrayList();
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter the number of users:");
		int n = Integer.parseInt(br.readLine());
		System.out.println("enter the user address in csv:" );
		for(int i=1;i<=n;i++) {
			String str = br.readLine();
			String s1[]= str.split(",");
			String name = s1[0];
	        String line1 = s1[1];
	        String line2 = s1[2];
	        int code = Integer.parseInt(s1[3]);
	        l.add(new Address(name,line1,line2,code));
		}
	 
		Collections.sort(l);
		Iterator<Address> itr = l.iterator();
		while(itr.hasNext()) {
			Address a = itr.next();
			System.out.println(a);
}
}
}


		