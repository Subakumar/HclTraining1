package cc;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.*;



public class Main {

	public static void main(String[] args)throws IOException, NumberFormatException {
		List<Stall> l = new ArrayList();
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("enter the number stall details:");
		int n = Integer.parseInt(br.readLine());
		for(int i=1;i<=n;i++) {
			System.out.println("enter the stall"+"\t"+i+"detail");
			String str = br.readLine();
			String s1[]= str.split(",");
			String name = s1[0];
	        String detail = s1[1];
	        String type = s1[2];
	        String ownername =s1[3];
			l.add(new Stall(name,detail,type,ownername));
		}
		
		Iterator<Stall> itr =  l.iterator();
		while(itr.hasNext()) {
			Stall s = itr.next();
			if(s.getName().startsWith("test"))
				itr.remove();
			else
				System.out.println(s);
			
		}
		
		
	}

}
