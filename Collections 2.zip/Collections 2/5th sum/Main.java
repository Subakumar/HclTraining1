package uu;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.*;




public class Main {

	public static void main(String[] args)throws IOException, NumberFormatException{
		List<User> l = new ArrayList();
	BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	System.out.println("Enter the number of user details:");
	int n = Integer.parseInt(br.readLine());
	for(int i=1;i<=n;i++) {
		System.out.println("enter the user" +i);
		String str = br.readLine();
		String s1[]= str.split(",");
		String name = s1[0];
        String mail = s1[1];
        String username = s1[2];
        String password =s1[3];
        l.add(new User(name,mail,username,password));
	}
		System.out.println("Sort by");
		System.out.println("1.name"+ "\n"+ "2.email");
		System.out.println("enter the choice:");
		int ch = Integer.parseInt(br.readLine());
		switch(ch) {
		case 1:
			Collections.sort(l,(new NameComparator()));
			break;
		case 2:
			Collections.sort(l,(new EmailComparator()));
			
			break;
		default:
				System.out.println("Invalid choice");
				break;
		}

		Iterator<User> itr = l.iterator();
		while(itr.hasNext()) {
			User u = itr.next();
			System.out.println(u);
			
		}
	}

}
