package rr;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.*;



public class Main {

	public static void main(String[] args)throws IOException {
		List<User> l = new ArrayList();
		HashMap<String,String> h = new HashMap();
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter the number of user:");
		int n = Integer.parseInt(br.readLine());
		for(int i=1;i<=n;i++) {
			System.out.println("enter the details of user" +i);
			String str = br.readLine();
			String s1[]= str.split(",");
			String name = s1[0];
	        String mobile = s1[1];
	        String username = s1[2];
	        String password =s1[3];
	        l.add(new User (name,mobile,username,password));
	}
		Collections.sort(l);
		Collections.reverse(l);
		System.out.println(l);
		for(int i =0;i<n;i++) {
			h.put(l.get(i).getName(),l.get(i).getMobilenumber());
			
		}
		System.out.println("enter the user details reversed:");
		System.out.format("%-15s%-15s\n"  , "Name","Mobile Number");
		Set s = h.entrySet();
		Iterator<HashMap> itr=s.iterator();
		while(itr.hasNext()) {
			Map.Entry m = (Map.Entry)itr.next();
			System.out.println(m);
		}
		
	}
}
