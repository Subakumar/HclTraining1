package rr;

public class User implements Comparable {
private String name;
private String mobilenumber;
private String username;
private String password;

public User() {
	
}

public User(String name, String mobilenumber, String username, String password) {
	super();
	this.name = name;
	this.mobilenumber = mobilenumber;
	this.username = username;
	this.password = password;
}

public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

public String getMobilenumber() {
	return mobilenumber;
}

public void setMobilenumber(String mobilenumber) {
	this.mobilenumber = mobilenumber;
}

public String getUsername() {
	return username;
}

public void setUsername(String username) {
	this.username = username;
}

public String getPassword() {
	return password;
}

public void setPassword(String password) {
	this.password = password;
}

@Override
public int compareTo(Object o) {
	User u1 = (User)o;
	return (u1.getName().compareTo(name));
}

@Override
public String toString() {
	System.out.format("%-15s%-15s\n" ,name,mobilenumber);
	return "";
}

}
