package tt;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.*;
public class Main {
public static void main(String args[])throws IOException,NumberFormatException {
	List<List<Integer>> daylist = new ArrayList();
	List<Integer>showlist = new ArrayList();
	BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	System.out.println("enter the count of booked tickets:");
	
	for(int i =1;i<=5;i++) {
		System.out.println("enter the day"+i);
		String str = br.readLine();
		String s1[]=str.split(",");
		int n1 = 100-Integer.parseInt(s1[0]);
		int n2 = 100-Integer.parseInt(s1[1]);
		int n3 = 100-Integer.parseInt(s1[2]);
		int n4 = 100-Integer.parseInt(s1[3]);
		
		showlist.add(n1);
		showlist.add(n2);
		showlist.add(n3);
		showlist.add(n4);
		
	}
	
	for(int i =1;i<=5;i++) {
		int j=0;
	daylist.add(showlist.subList(j, j+4));
     j=j+4;
    
     
     
	}
	do {
	System.out.println("Enter the day to know its remaining ticket count:");
	int num = Integer.parseInt(br.readLine());
	System.out.println("Remaining tickets:"+  daylist.get(num));
	System.out.println("Do you want to continue");
	String s = br.readLine();
	if(s.contentEquals("yes")) 
		break;
	
	}while(true);
	}
	
}

