package mm;
import java.util.Comparator;

public class Maxi implements Comparator{
String customerName;
Integer price;

public Maxi() {
	
}

public Maxi(String customerName, Integer price) {
	super();
	this.customerName = customerName;
	this.price = price;
}

public String getCustomerName() {
	return customerName;
}

public void setCustomerName(String customerName) {
	this.customerName = customerName;
}

public Integer getPrice() {
	return price;
}

public void setPrice(Integer price) {
	this.price = price;
}

@Override
public int compare(Object o1, Object o2) {
	Maxi m1 = (Maxi)o1;
	Maxi m2 = (Maxi)o2;
	if(m1.price<m2.price)
		return -1;
	else if(m1.price>m2.price)
		return 1;
	else
	return 0;
}



}


