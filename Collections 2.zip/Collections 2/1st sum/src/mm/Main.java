package mm;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.*;
import java.util.Comparator;
import java.util.Collections;
public class Main {

	public static void main(String[] args)throws IOException,NumberFormatException {
		
		List<Maxi> l = new ArrayList<>();
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		
		System.out.println("enter the number of customers:");
		int n =  Integer.parseInt(br.readLine());
		System.out.println("enter the booking price according with customer name in Csv format  ");
		for(int i=0;i<n;i++) {
			String str = br.readLine();
			String s1[]= str.split(",");
			String name = s1[0];
			int cost = Integer.parseInt(s1[1]);
			l.add(new Maxi(name,cost));
		}
		Comparator com = (Comparator) new Maxi();
			Maxi m1 =Collections.max(l, com);
			System.out.println(m1.getCustomerName() +"spends maximum amount"+m1.getPrice());
			Maxi m2 = Collections.min(l, com);
			System.out.println(m2.getCustomerName()+"spends minimum amount"+m2.getPrice());
			
			
		}
	

	
	

}
