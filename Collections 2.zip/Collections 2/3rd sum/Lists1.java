package ss;

public class Lists1 implements Comparable{
private String name;
private Double costPerDay;
private String contactNumber;
private String ownerName;

public Lists1() {
	
}

public Lists1(String name, Double costPerDay, String contactNumber, String ownerName) {
	super();
	this.name = name;
	this.costPerDay = costPerDay;
	this.contactNumber = contactNumber;
	this.ownerName = ownerName;
}

public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

public Double getCostPerDay() {
	return costPerDay;
}

public void setCostPerDay(Double costPerDay) {
	this.costPerDay = costPerDay;
}

public String getContactNumber() {
	return contactNumber;
}

public void setContactNumber(String contactNumber) {
	this.contactNumber = contactNumber;
}

public String getOwnerName() {
	return ownerName;
}

public void setOwnerName(String ownerName) {
	this.ownerName = ownerName;
}

@Override
public String toString() {
	
	System.out.format("%-15s%-15s%-15s%-15s\n" ,name,costPerDay,contactNumber,ownerName);
	System.out.println();
	return"";
}

@Override
public int compareTo(Object o) {
	Lists1 l = (Lists1)o;
	if(l.costPerDay< costPerDay)
		return +1;
	else if (l.getCostPerDay()>costPerDay)
	return -1;
	else
	return 0;
}


}
