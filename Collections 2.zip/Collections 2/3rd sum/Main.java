package ss;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.*;

public class Main {

	public static void main(String[] args)throws IOException,NumberFormatException {
		List<Lists1> l = new ArrayList();
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter the number of halls:");
		int n = Integer.parseInt(br.readLine());
		for(int i=1;i<=n;i++) {
			System.out.println("enter the hall" +i);
			String str = br.readLine();
			String s1[]= str.split(",");
			String name = s1[0];
	        double cost = Double.parseDouble(s1[1]);
	        String number = s1[2];
	        String ownername =s1[3];
	        l.add(new Lists1(name,cost,number,ownername));
	   
		}
		
		Collections.sort(l);
		System.out.format("%-15s%-15s%-15s%-15s \n" ,"name","costPerDay","contactNumber","ownerName");
		Iterator<Lists1> itr = l.iterator();
		while(itr.hasNext()) {
			Lists1 l1 = itr.next();
			System.out.println(l1);
		}
 		

	}

}
