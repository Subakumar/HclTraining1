package com.session;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/Welcome")
public class Welcome extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
   protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();
	    String event = request.getParameter("Event Name");
		HttpSession session = request.getSession();	
		session.setAttribute("Event Name", event);
		pw.write("<center>");
		pw.write("<h1>Event Management System</h1>");
		pw.write("<form action='./Display' method ='Get'>");
		
		pw.write("<table>");
		pw.write("Welcome to this event Rio carnival");
		pw.write("<tr><td><input type ='submit'value='Get Detail\"></td><tr><br>");
		pw.write("</table>");
		pw.write("</form>");
		pw.write("</center>");
		
		pw.close();
		
	}

	
	}


