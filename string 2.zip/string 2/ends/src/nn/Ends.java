package nn;
import java.util.*;

public class Ends {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the string:");
		String s1 = sc.nextLine();
		if(s1.endsWith("com")||(s1.endsWith("in"))||(s1.endsWith("net"))||(s1.endsWith("org"))) {
			System.out.println("valid email address");
		}
		else {
			System.out.println("Invalid email address");
		}
		
		

	}

}
