package dd;
import java.util.*;
public class Date {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the date:");
		String s1 = sc.nextLine();
		
		if(s1.contains("*")) {
			String s2 = s1.replace("*", "-");
			System.out.println("Enter the date in correct format:"+s2);
		}
		else if(s1.contains("/")) {
			String s3 = s1.replace("/","-");
			System.out.println("Enter the date in correct format:"+s3);
		}
		else {
			String s4 = s1.replace("", "-");
			System.out.println("Enter the date in correct format:"+s4);
		}


	}

}
