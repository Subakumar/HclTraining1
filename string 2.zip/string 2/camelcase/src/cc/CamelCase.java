package cc;
import java.util.*;
public class CamelCase {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the event name:");
	   String s1 = sc.nextLine();
		String uppercase ="";
		Scanner scanner = new Scanner(s1);
		while(scanner.hasNext()) {
			String word = scanner.next();
			 uppercase+=Character.toUpperCase(word.charAt(0))+word.substring(1)+"";
			
		}
System.out.println(uppercase.replace("//s",""));
	}

}
