const eventnames=new Array();
function addEvent(){
    const name=document.getElementById("eventName").value;
    if(eventnames.length===0){
        eventnames.push(name);
        document.getElementById("successMessage").innerHTML="event name added successfully";

    }
    else{
        let i=0;
        for(let j=0;j<eventnames.length;j++){
            if(eventnames[j]===name)
            {
                i++;
            }
        }
    if(i===0){
        eventnames.push(name);
        document.getElementById("successMessage").innerHTML="event name added succesfully";
    }
    else{
        document.getElementById("successMessage").innerHTML="Event name already exists.Try with some other one";
    }
    }
}
  function displayEvent(){
      for(let k=0;k<eventnames.length;k++){
          document.getElementById("resultTable").innerHTML +="<tr><td>"+ eventnames[k] +"</td></tr>";
      }
  }



       
    
    
    
    
    
