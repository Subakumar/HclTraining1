const EventNames=[];
function pushelement(){
    document.getElementById("events1").innerHTML="";
    document.getElementById("resultlist").innerHTML="";
    const name=document.getElementById("input").value;
    if(EventNames.length===0){
        EventNames.push(name);
        document.getElementById("events").innerHTML="events added successfully";
    }
    else{
        let i=0;
        for(let j=0;j<eventNames.length;j++){
            if(EventNames[j]===name)
            {
                i++;
            }
        }
    if(i===0){
        EventNames.push(name);
        document.getElementById("events").innerHTML="event added succesfully";
    }
    else{
        document.getElementById("events").innerHTML="Event name already exists.Try with some other one";
    }
    }
}
  function popelement(){
      document.getElementById("resultth3").innerHTML="";
      document.getElementById("eventList").innerHTML="";
      if(eventNames.length===0){
          document.getElementById("events").innerHTML="event array is empty";
      }
      else{
          eventNames.pop();
          document.getElementById("events").innerHTML="removed succesfully" }
      }
  function display(){
      if(eventNames.length===0){
          document.getElementById("events1").innerHTML="";
      }
      else{ document.getElementById("events1").innerHTML="the events in the array";
          for(let k=0;k<eventNames.length;k++){
              document.getElementById("resultList").innerHTML += "<li>" +EventNames[k]+ "</li>" ;
          }
  }

  }
