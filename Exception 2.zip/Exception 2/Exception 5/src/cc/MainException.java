package cc;
import java.util.*;
public class MainException {
	public static void main(String s[]) {
		try {
	int a[] = new int[10];
Scanner sc = new Scanner(System.in);
System.out.println("enter the values:");
for(int i=0;i<a.length;i++) 
{
	a[i] =sc.nextInt();
}
System.out.println("enter a number:");
int n = sc.nextInt();

 for(int j=10;j>0;j--) {
	 int result = a[j-1]/n;
	 System.out.println(result);
 }
 }
		catch(ArithmeticException e) {
			System.out.println("cannot divide by zero");
		}

	}
	
}
