package ii;
import java.util.*;
public class IllegalArgument extends Exception {

	public static void main(String[] args)throws IllegalArgumentException {
		
		int a[] = new int[10];
Scanner sc = new Scanner(System.in);
System.out.println("enter the array elements");
for(int i=0;i<10;i++) {
a[i]= sc.nextInt();
}
System.out.println("enter the divisor");
int d = sc.nextInt();
try {
for(int i=0;i<10;i++) {
	if((d%2==0)&&(a[i]%2!=0)) {
	throw new IllegalArgumentException();
	}
	else if((d%2!=0&&(a[i]%2==0))) {
		throw new IllegalArgumentException();
	}
	else {
		System.out.println("Result:"+ a[i]/d);
		
	}
}
}
		
catch(IllegalArgumentException ae) {
	System.out.println("exception handled in method");
	for(int i=0;i<10;i++) {
	System.out.println("Result:"+a[i]/d);
}
}

	
}
	}



