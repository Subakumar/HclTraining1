package tt;

import java.util.Scanner;

public class Throws {

	public static void main(String[] args) throws IllegalArgumentException {
		int a[] = new int[10];
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the array elements");
		for(int i=0;i<10;i++) {
		a[i]= sc.nextInt();
		}
		System.out.println("enter the divisor");
		int d = sc.nextInt();
		try {
		for(int i=0;i<10;i++) {
			if((d%2==0)&&(a[i]%2!=0)) {
			throw new IllegalArgumentException();
			}
			else if((d%2!=0&&(a[i]%2==0))) {
				throw new IllegalArgumentException();
			}
			else {
				System.out.println("Result:"+ a[i]/d);
				
			}
	}

}
		catch(IllegalArgumentException ae) {
			System.out.println("Exception handled in the main() method");
		}
	}
}
