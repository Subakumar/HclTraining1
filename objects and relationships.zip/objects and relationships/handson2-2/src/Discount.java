
public class Discount {
private int productcode;
private String productname;
private double price;
private int stock;
private String Staticname;

public Discount() {
	
}

public Discount(int productcode, String productname, double price, int stock, String staticname) {
	super();
	this.productcode = productcode;
	this.productname = productname;
	this.price = price;
	this.stock = stock;
	Staticname = staticname;
}

public int getProductcode() {
	return productcode;
}

public void setProductcode(int productcode) {
	this.productcode = productcode;
}

public String getProductname() {
	return productname;
}

public void setProductname(String productname) {
	this.productname = productname;
}

public double getPrice() {
	return price;
}

public void setPrice(double price) {
	this.price = price;
}

public int getStock() {
	return stock;
}

public void setStock(int stock) {
	this.stock = stock;
}

public String getStaticname() {
	return Staticname;
}

public void setStaticname(String staticname) {
	Staticname = staticname;
}
void checkPrice(Discount d, Discount d1) {
	if(d.getPrice()>d1.getPrice()) {
		System.out.println(d1.getProductname()+"is cheaper than"+ d.getProductname());
		}
	else {
		System.out.println(d.getProductname()+"is cheaper than"+ d1.getProductname());
	}
	}
 void getDiscountedPrice(Discount Disc) {
	 
	if(Disc.getPrice()>=80000) {
		double s1=0.3*Disc.getPrice();
		
			System.out.println( Staticname);
			System.out.println("Product Code:"+ productcode);
			System.out.println("Product Name:"+productname);
			System.out.println("Price:"+price);
			System.out.println("stock:"+stock);
			System.out.println("Discount price:"+s1);
		
	}else if(Disc.getPrice()>=60000){
		double s2 =0.2*Disc.getPrice();
		System.out.println( Staticname);
		System.out.println("Product Code:"+ productcode);
		System.out.println("Product Name:"+productname);
		System.out.println("Price:"+price);
		System.out.println("stock:"+stock);
		System.out.println("Discount price:"+s2);
		
	}else if(Disc.getPrice()>=50000) {
		double s3=0.1*Disc.getPrice();
		System.out.println( Staticname);
		System.out.println("Product Code:"+ productcode);
		System.out.println("Product Name:"+productname);
		System.out.println("Price:"+price);
		System.out.println("stock:"+stock);
		System.out.println("Discount price:"+s3);
	}else {
		double s4=0.5*Disc.getPrice();
		System.out.println( Staticname);
		System.out.println("Product Code:"+ productcode);
		System.out.println("Product Name:"+productname);
		System.out.println("Price:"+price);
		System.out.println("stock:"+stock);
		System.out.println("Discount price:"+s4);
	}
}
		void Display() {
		System.out.println( Staticname);
		System.out.println("Product Code:"+ productcode);
		System.out.println("Product Name:"+productname);
		System.out.println("Price:"+price);
		System.out.println("stock:"+stock);
	}
 
 
}

