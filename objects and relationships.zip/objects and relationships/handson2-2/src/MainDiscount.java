import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;

public class MainDiscount {

	public static void main(String[] args) throws IOException{
		Discount d = new Discount();
BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("enter the product code:");
		int productcode= Integer.parseInt(br.readLine());
		System.out.println("enter the product name:");
		String productname = br.readLine();
		System.out.println("enter the price:");
		double price = Double.parseDouble(br.readLine());
		System.out.println("enter the stock:");
		int stock = Integer.parseInt(br.readLine());
		d.setProductcode(productcode);
		d.setProductname(productname);
		d.setPrice(price);
		d.setStock(stock);
		d.setStaticname("L&K Suppliers");
		
		Discount d1 = new Discount();
		System.out.println("enter the product code:");
		int productcode1= Integer.parseInt(br.readLine());
		System.out.println("enter the product name:");
		String productname1 = br.readLine();
		System.out.println("enter the price:");
		double price1 = Double.parseDouble(br.readLine());
		System.out.println("enter the stock:");
		int stock1 = Integer.parseInt(br.readLine());
		d1.setProductcode(productcode1);
		d1.setProductname(productname1);
		d1.setPrice(price1);
		d1.setStock(stock1);
		d1.setStaticname("L&K Suppliers");
		
		d.getDiscountedPrice(d);
		d.Display();
		d1.getDiscountedPrice(d1);
		d1.Display();
		Discount d3 = new Discount();
		d3.checkPrice(d,d1);
		
		
		
	}

}
