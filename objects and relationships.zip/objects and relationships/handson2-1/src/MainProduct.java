import java.io.BufferedReader;
import java.lang.NumberFormatException;
import java.io.InputStreamReader;
import java.io.IOException;
public class MainProduct {

	public static void main(String[] args) throws NumberFormatException,IOException{
		Product p = new Product();
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("enter the product code:");
		int productcode = Integer.parseInt( br.readLine());
		System.out.println("enter the product name:");
		String productname = br.readLine();
		System.out.println("enter the price:");
		double price = Double.parseDouble(br.readLine());
		System.out.println("enter the stock:");
		int stock = Integer.parseInt(br.readLine());
		p.setProductcode(productcode);
		p.setProductname(productname);
		p.setPrice(price);
		p.setStock(stock);
		
		
		Product p1= new Product();
		System.out.println("enter the product code:");
		int productcode1 = Integer.parseInt( br.readLine());
		System.out.println("enter the product name:");
		String productname1 = br.readLine();
		System.out.println("enter the price:");
		double price1 = Double.parseDouble(br.readLine());
		System.out.println("enter the stock:");
		int stock1 = Integer.parseInt(br.readLine());
		p1.setProductcode(productcode1);
		p1.setProductname(productname1);
		p1.setPrice(price1);
		p1.setStock(stock1);
		System.out.println("enter the product details:");
		System.out.println("product code;"+p.getProductcode());
		System.out.println("Product Name:"+p.getProductname());
		System.out.println("price:"+p.getPrice());
		System.out.println("stock:"+p.getStock());
		
		System.out.println("enter the product details:");
		System.out.println("product code;"+p1.getProductcode());
		System.out.println("Product Name:"+p1.getProductname());
		System.out.println("price:"+p1.getPrice());
		System.out.println("stock:"+p1.getStock());
		
		Product p2 = new Product();
		p2.checkPrice(p,p1);
		}

	

}

