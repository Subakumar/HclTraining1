
public class Product {
private int productcode;
private String productname;
private double price;
private int stock;

public Product() {
	
}

public Product(int productcode, String productname, double price, int stock) {
	super();
	this.productcode = productcode;
	this.productname = productname;
	this.price = price;
	this.stock = stock;
}

public int getProductcode() {
	return productcode;
}

public void setProductcode(int productcode) {
	this.productcode = productcode;
}

public String getProductname() {
	return productname;
}

public void setProductname(String productname) {
	this.productname = productname;
}

public double getPrice() {
	return price;
}

public void setPrice(double price) {
	this.price = price;
}

public int getStock() {
	return stock;
}

public void setStock(int stock) {
	this.stock = stock;
}
void checkPrice(Product p,  Product p1) {

if(p1.getPrice()>p.getPrice()) {
	System.out.println(p.getProductname()+"is cheaper than " + p1.getProductname());
}
else {
	System.out.println(p1.getProductname()+" is cheaper than"+ p.getProductname());
}
}
}
