package org.demo1;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/Exhibition")
public class Exhibition extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter pw =response.getWriter();
		pw.write("<html>");
		pw.write("<body>");
		pw.write("<h1 style=color:Green;> TextFair 2018 Expo</h1>");
		pw.write("<table border ='3'>");
		pw.write("<tr>");
		pw.write("<th>Name</th>");
		pw.write("<th> Text Fair 2017Expo</th>");
		pw.write("</tr>");
		pw.write("<tr>");
		pw.write("<td>Hall Name</td>");
		pw.write("<td>PVR SuperPlex");
		pw.write("</tr>");
		pw.write("<tr>");
		pw.write("<td> start date</td>");
		pw.write("<td> 06-10-2020 </td>");
		pw.write("</tr>");
		pw.write("<tr>");
		pw.write("<td>End Date");
		pw.write("<td>06-10-2030</td>");
		pw.write("</tr>");
		pw.write("</table>");
		pw.write("</body>");
		pw.write("</html>");
		pw.close();
		
	}

}
