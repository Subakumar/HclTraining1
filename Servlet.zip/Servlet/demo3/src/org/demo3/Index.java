package org.demo3;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/Index")
public class Index extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();
	
		pw.write("<body>");
		pw.write("<h1 style =color:Green;> Event Creation </h1>");
		pw.write("<table >");
		pw.write("<form action =\"./Validate\"method =\"get\">");
		pw.write("<tr><td>Event Name:</td><td><input type=\"\text\" name=\"name\"></td></tr><br>");
		pw.write("<tr><td>Hall Name:</td><td><input type=\"\text\" name=\"HName\"></td></tr><br>");
		pw.write("<tr><td>Event Type:</td><td><input type=\"radio\" value ='Exhibition' name=\"type\">Exhibition<br>"+
		"<input type=\"radio\" value ='Stage Show' name=\"type\">Stage Show</td></tr><br>");
		pw.write("<tr><td>Details:</td><td><input type=\"\text\" name =\"details\"></td></tr><br>");
		pw.write("<tr><td>Owner:</td><td><input type=\"\text\" name =\"owner\"></td></tr><br>");
		pw.write("<tr><td>Start Date:</td><td><input type=\"\text\" name =\"SDate\"></td></tr><br>");
		pw.write("<tr><td>End Date:</td><td><input type=\"\text\" name =\"EDate\"></td></tr><br>");
		pw.write("<tr><td></td><td><input type=\"submit\"value=\"create\"></td></tr><br>");
		pw.write("</form");
		pw.write("</table>");
		pw.write("</body>");
		
	}	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();
	
		pw.write("<body>");
		pw.write("<h1 style =color:Green;> Event Creation </h1>");
		pw.write("<table>");
		pw.write("<form action =\"./Validate\"method =\"get\">");
		pw.write("<tr><td>Event Name:</td><td><input type=\"\text\" name=\"name\"></td></tr>");
		pw.write("<tr><td>Hall Name:</td><td><input type=\"\text\" name=\"HName\"></td></tr>");
		pw.write("<tr><td>Event Type:</td><td><input type=\"radio\" value ='Exhibition' name=\"type\">Exhibition<br>"+
		"<input type=\"radio\" value ='Stage Show' name=\"type\">Stage Show</td></tr>");
		pw.write("<tr><td>Details:</td><td><input type=\"\text\" name =\"details\"></td></tr>");
		pw.write("<tr><td>Owner:</td><td><input type=\"\text\" name =\"owner\"></td></tr>");
		pw.write("<tr><td>Start Date:</td><td><input type=\"\text\" name =\"SDate\"></td></tr>");
		pw.write("<tr><td>End Date:</td><td><input type=\"\text\" name =\"EDate\"></td></tr>");
		pw.write("<tr><td></td><td><input type=\"submit\"value=\"create\"></td></tr>");
		pw.write("</form");
		pw.write("</table>");
		pw.write("</body>");
		
	}	
	

}
