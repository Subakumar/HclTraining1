package org.demo3;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/Validate")
public class Validate extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();
		String Eventname =request.getParameter("name");
		String Hallname =request.getParameter("HName");
		String Eventtype = request.getParameter("type");
		String details =request.getParameter("details");
		String owner =request.getParameter("owner");
		String StartDate =request.getParameter("SDate");
		String EndDate =request.getParameter("EDate");
		if(Eventname==""|| Hallname==""|| Eventtype==""||details==""||owner==""||StartDate==""||EndDate=="") {
			RequestDispatcher rd = request.getRequestDispatcher("./Index");
			pw.write("<h1>Event Creation</h1>");
			if(Eventname.length()==0) {
				pw.write("Event Name must not be Empty");
			}
			if(Hallname.length()==0) {
				pw.write("Hall name must not be empty");
			}
			if(Eventtype.length()==0) {
				pw.write("Event Type must not be empty");
			}
			if(details.length()==0) {
				pw.write("Details must not be empty");
			}
			if(owner.length()==0) {
				pw.write("Owner must not be empty");
				
			}
			if(StartDate.length()==0) {
				pw.write("StartDate must not be empty");
			}
			if(EndDate.length()==0) {
				pw.write("EndDate must not be empty");
			}
		
			rd.include(request,response);
			
			
		}
		else {
			pw.write("<h1> Events Created Successfully</h1>");
			pw.write("<h3>Event details</h3>");
			pw.write("<table border='3'>");
			pw.write("<tr><td>EventName</td><td>"+Eventname+"</td><tr>");
			pw.write("<tr><td>HallName</td><td>"+Hallname+"</td><tr>");
			pw.write("<tr><td>Event Type</td><td>"+Eventtype+"</td><tr>");
			pw.write("<tr><td>Details</td><td>"+details+"</td><tr>");
			pw.write("<tr><td>owner</td><td>"+owner+"</td><tr>");
			pw.write("<tr><td>StartDate</td><td>"+StartDate+"</td><tr>");
			pw.write("<tr><td>End Date</td><td>"+EndDate+"</td><tr>");
		}
		
		
	}

}
