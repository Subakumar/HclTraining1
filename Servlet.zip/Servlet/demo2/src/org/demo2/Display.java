package org.demo2;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/Display")
public class Display extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public Display() {
        super();
       
    }
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();
		String uname =request.getParameter("name");
		String pno =request.getParameter("phonenumber");
		String email = request.getParameter("email");
		String city =request.getParameter("city");
	
		pw.write("<body>");
		pw.write("<table border='1'>");
		pw.write("<tr>");
		pw.write("<td>Name</td><td>Phone Number</td><td>Email</td><td>City</td></tr>");
		pw.write("<tbody>");
		pw.write("<tr><td>"+uname+"</td><td>"+pno+"</td><td>"+email+"</td><td>"+city+"</td></tr>");
	    pw.write("</tbody>");
		pw.write("</table>");
		pw.write("</body>");
		pw.close();
	}

}
