package org.demo2;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/Index")
public class Index extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
    public Index() {
        super();
       
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();
	
		
		pw.write("<body>");
		pw.write("<h1> USER DETAILS</h1>");
		pw.write("<table>");
		pw.write("<form action =\"./Display\"method =\"post\">");
		pw.write("<tr><td>Name:</td><td><input type=\"\text\" name=\"name\"></td></tr><br>");
		pw.write("<tr><td>PhoneNumber:</td><td><input type=\"\text\" name=\"phonenumber\"></td></tr><br>");
		pw.write("<tr><td>Email:</td><td><input type=\"\text\" name =\"email\"></td></tr><br>");
		pw.write("<tr><td>city:</td><td><input type=\"\text\" name =\"city\"></td></tr><br>");
		pw.write("<tr><td><input type=\"submit\"name=\"submit\"></td></tr><br>");

		pw.write("</form");
		pw.write("</table>");
		pw.write("</body>");
		
	
		
		
	}

}
