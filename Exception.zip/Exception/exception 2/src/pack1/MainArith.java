package pack1;
import java.util.*;
public class MainArith {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the cost for n days:");
		int cost = sc.nextInt();
		System.out.println("enter the value of n:");
		int n = sc.nextInt();
		sc.nextLine();
		int total = cost/n;
		System.out.println("cost per day of the item is:"+total);
		}
		catch(ArithmeticException e) {
			System.out.println(e);
			}

		
		
	}

}
