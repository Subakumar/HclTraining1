package eee;
import java.io.*;


public class MainNumber {

	public static void main(String[] args)throws IOException {
		
	try {	
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("enter the deposit:");
		double a=Double.parseDouble(br.readLine());
	
		System.out.println("enter the cost per day:");
		double b = Double.parseDouble(br.readLine());
		
		System.out.println("enter the name:");
		String name = (br.readLine());
		NumberFormat nf = new NumberFormat(name,a,b);
		
		String s = nf.toString();
		
	}
	catch(NumberFormatException nfe) {
		System.out.println(nfe);
	}
		
		
		
		
		
		

	}

}
