package bb;
import java.util.*;

public class Exception {
	public static void main(String s[]) {

Scanner sc = new Scanner(System.in);
try {
	System.out.println("enter an integer:");
	int n = sc.nextInt();
	System.out.println("enter the number:"+n);
}
catch(InputMismatchException e) {
	System.out.println(e);
}
}
}
