package ee;
import java.util.*;
public class Array {
	public static void main(String s[]) {

		try {
			int a[] = new int[10];
			Scanner sc = new Scanner(System.in);
			System.out.println("enter the values:");
			for(int i=0;i<a.length;i++) 
				{
					a[i] =sc.nextInt();
				}
			for(int j=10,k=0;j>=0;j--,k++) {
				int result =a[k]/j;
				System.out.println("Result:"+result);
				}
				
			
			}
				catch(ArrayIndexOutOfBoundsException e){
					System.out.println(e);
				}
				}
		
				
				
				
				
				
				
				
				
		
	}
	
	
	
	
	

